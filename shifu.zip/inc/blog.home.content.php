						<div class="col-lg-12">
							<article class="thePost">
								<div class="thumb">
									<a href="blog.single.php">
										<img src="img/blog/03.jpg" alt="Blog Thumb">
										<i class="fa fa-link"></i>
									</a>
								</div>
								<header>
									<h2>
										<a href="blog.single.php" class="tdu f1 fw-7">Quibusdam necessitatibus sunt</a>
									</h2>
								</header>
								<div class="summary">
									<p class="txt-normal">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid iusto, quibusdam necessitatibus sunt praesentium possimus. Adipisci. laudantium magnam maiores cumque.... <a href="blog.single.php" class="c1 f1 fw-9"><span class="tdu">read more</span> <i class="fa fa-arrow-right pl-1"></i></a></p>
								</div>
								<footer>
									<div class="metaData f1 text-capitalize text-center">
										<span>
											<i class="fa fa-user"></i>
											<a href="#">john doe</a>
										</span>
										<span>
											<i class="fa fa-calendar"></i>
											<a href="#">2019 - 01 - 04</a>
										</span>
										<span>
											<i class="fa fa-tags"></i>
											<a href="#">Auto Hauler</a>
										</span>
									</div>
								</footer>
							</article>
						</div>
						<div class="col-lg-12">
							<article class="thePost">
								<div class="thumb">
									<a href="blog.single.php">
										<img src="img/blog/04.jpg" alt="Blog Thumb">
										<i class="fa fa-link"></i>
									</a>
								</div>
								<header>
									<h2>
										<a href="blog.single.php" class="tdu f1 fw-7">Consectetur possimus molestiae.</a>
									</h2>
								</header>
								<div class="summary">
									<p class="txt-normal">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid iusto, quibusdam necessitatibus sunt praesentium possimus. Adipisci. laudantium magnam maiores cumque.... <a href="blog.single.php" class="c1 f1 fw-9"><span class="tdu">read more</span> <i class="fa fa-arrow-right pl-1"></i></a></p>
								</div>
								<footer>
									<div class="metaData f1 text-capitalize text-center">
										<span>
											<i class="fa fa-user"></i>
											<a href="#">john doe</a>
										</span>
										<span>
											<i class="fa fa-calendar"></i>
											<a href="#">2019 - 01 - 04</a>
										</span>
										<span>
											<i class="fa fa-tags"></i>
											<a href="#">Auto Hauler</a>
										</span>
									</div>
								</footer>
							</article>
						</div>
						<div class="col-lg-12">
							<article class="thePost">
								<div class="thumb">
									<a href="blog.single.php">
										<img src="img/blog/05.jpg" alt="Blog Thumb">
										<i class="fa fa-link"></i>
									</a>
								</div>
								<header>
									<h2>
										<a href="blog.single.php" class="tdu f1 fw-7">Quibusdam necessitatibus sunt</a>
									</h2>
								</header>
								<div class="summary">
									<p class="txt-normal">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid iusto, quibusdam necessitatibus sunt praesentium possimus. Adipisci. laudantium magnam maiores cumque.... <a href="blog.single.php" class="c1 f1 fw-9"><span class="tdu">read more</span> <i class="fa fa-arrow-right pl-1"></i></a></p>
								</div>
								<footer>
									<div class="metaData f1 text-capitalize text-center">
										<span>
											<i class="fa fa-user"></i>
											<a href="#">john doe</a>
										</span>
										<span>
											<i class="fa fa-calendar"></i>
											<a href="#">2019 - 01 - 04</a>
										</span>
										<span>
											<i class="fa fa-tags"></i>
											<a href="#">Auto Hauler</a>
										</span>
									</div>
								</footer>
							</article>
						</div>
						<div class="col-lg-12">
							<article class="thePost">
								<div class="thumb">
									<a href="blog.single.php">
										<img src="img/blog/03.jpg" alt="Blog Thumb">
										<i class="fa fa-link"></i>
									</a>
								</div>
								<header>
									<h2>
										<a href="blog.single.php" class="tdu f1 fw-7">Consectetur possimus molestiae.</a>
									</h2>
								</header>
								<div class="summary">
									<p class="txt-normal">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid iusto, quibusdam necessitatibus sunt praesentium possimus. Adipisci. laudantium magnam maiores cumque.... <a href="blog.single.php" class="c1 f1 fw-9"><span class="tdu">read more</span> <i class="fa fa-arrow-right pl-1"></i></a></p>
								</div>
								<footer>
									<div class="metaData f1 text-capitalize text-center">
										<span>
											<i class="fa fa-user"></i>
											<a href="#">john doe</a>
										</span>
										<span>
											<i class="fa fa-calendar"></i>
											<a href="#">2019 - 01 - 04</a>
										</span>
										<span>
											<i class="fa fa-tags"></i>
											<a href="#">Auto Hauler</a>
										</span>
									</div>
								</footer>
							</article>
						</div>
						<div class="col-lg-12">
							<article class="thePost">
								<div class="thumb">
									<a href="blog.single.php">
										<img src="img/blog/04.jpg" alt="Blog Thumb">
										<i class="fa fa-link"></i>
									</a>
								</div>
								<header>
									<h2>
										<a href="blog.single.php" class="tdu f1 fw-7">Quibusdam necessitatibus sunt</a>
									</h2>
								</header>
								<div class="summary">
									<p class="txt-normal">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid iusto, quibusdam necessitatibus sunt praesentium possimus. Adipisci. laudantium magnam maiores cumque.... <a href="blog.single.php" class="c1 f1 fw-9"><span class="tdu">read more</span> <i class="fa fa-arrow-right pl-1"></i></a></p>
								</div>
								<footer>
									<div class="metaData f1 text-capitalize text-center">
										<span>
											<i class="fa fa-user"></i>
											<a href="#">john doe</a>
										</span>
										<span>
											<i class="fa fa-calendar"></i>
											<a href="#">2019 - 01 - 04</a>
										</span>
										<span>
											<i class="fa fa-tags"></i>
											<a href="#">Auto Hauler</a>
										</span>
									</div>
								</footer>
							</article>
						</div>
						<div class="col-lg-12">
							<article class="thePost">
								<div class="thumb">
									<a href="blog.single.php">
										<img src="img/blog/05.jpg" alt="Blog Thumb">
										<i class="fa fa-link"></i>
									</a>
								</div>
								<header>
									<h2>
										<a href="blog.single.php" class="tdu f1 fw-7">Consectetur possimus molestiae.</a>
									</h2>
								</header>
								<div class="summary">
									<p class="txt-normal">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid iusto, quibusdam necessitatibus sunt praesentium possimus. Adipisci. laudantium magnam maiores cumque.... <a href="blog.single.php" class="c1 f1 fw-9"><span class="tdu">read more</span> <i class="fa fa-arrow-right pl-1"></i></a></p>
								</div>
								<footer>
									<div class="metaData f1 text-capitalize text-center">
										<span>
											<i class="fa fa-user"></i>
											<a href="#">john doe</a>
										</span>
										<span>
											<i class="fa fa-calendar"></i>
											<a href="#">2019 - 01 - 04</a>
										</span>
										<span>
											<i class="fa fa-tags"></i>
											<a href="#">Auto Hauler</a>
										</span>
									</div>
								</footer>
							</article>
						</div>