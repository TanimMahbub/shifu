
						<div class="blog-sidebar">
							<div class="customWidget">
								<form>
									<input type="search" placeholder="Search here..">
								</form>
							</div>
							<div class="customWidget">
								<h2>latest post</h2>
								<ul>
									<li><a href="#">Quibusdam necessitatibus sunt</a></li>
									<li><a href="#">Consectetur possimus molestiae.</a></li>
									<li><a href="#">Soluta eaque voluptas facilis a, repudiandae!</a></li>
									<li><a href="#">Totam dolores sit, blanditiis, repellat error.</a></li>
									<li><a href="#">Adipisicing elit.</a></li>
								</ul>
							</div>
							<div class="customWidget">
								<h2>popular post</h2>
								<ul>
									<li><a href="#">Soluta eaque voluptas facilis a, repudiandae!</a></li>
									<li><a href="#">Consectetur possimus molestiae.</a></li>
									<li><a href="#">Totam dolores sit, blanditiis, repellat error.</a></li>
									<li><a href="#">Adipisicing elit.</a></li>
									<li><a href="#">Quibusdam necessitatibus sunt</a></li>
								</ul>
							</div>
							<div class="customWidget">
								<h2>popular tags</h2>
								<a href="#">truck</a>
								<a href="#">Heavy Haul</a>
								<a href="#">Superloads</a>
								<a href="#">Flatbed Trucking</a>
								<a href="#">Backhoes</a>
								<a href="#">Containers</a>
							</div>
						</div>