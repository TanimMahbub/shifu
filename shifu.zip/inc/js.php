        <div class="back2Top bg1 wave"> 
            <i class="fa fa-sort-asc cw"></i>
        </div>
        <script src="js/jquery-1.12.4.min.js"></script>
        <script src="js/queryloader2.min.js"></script>
        <script src="js/bootstrap.bundle.min.js"></script>
        <script src="js/wow.min.js"></script>
        <script src="js/jquery.filterizr.min.js"></script>
        <script src="js/waves.min.js"></script>
        <script src="js/jquery.enllax.min.js"></script>
        <script src="js/SmoothScroll.js"></script>
        <script src="js/lightbox.js"></script>
        <script src="js/tilt.jquery.js"></script>
        <script src="js/jquery.malihu.PageScroll2id.min.js"></script>
        <script src="js/jquery.validate.min.js"></script>
        <script src="js/main.js"></script>
    </body>

</html>