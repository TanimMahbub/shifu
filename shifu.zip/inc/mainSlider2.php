<div class="mainSlider2" id="home">
	<div class="banner-carousel owl-carousel">
		<div class="ms2-item bg1 f1">
			<div class="row justify-content-center align-items-center h-100">
				<div class="col-lg-8">
					<div class="ms2-content">
						<h1 class="ob-1 cw fw-7">hi there, welcome</h1>
						<h2 class="ob-2">
							<span>to my world</span>
						</h2>
						<a href="#about" rel="m_PageScroll2id" class="sliderBtn wave bg-white c1">Learn more</a>
					</div>
				</div>
			</div>
		</div>
		<div class="ms2-item bg1 f1">
			<div class="row justify-content-center align-items-center h-100">
				<div class="col-lg-8">
					<div class="ms2-content">
						<h1 class="ob-1 cw fw-7">I'm John Doe</h1>
						<h2 class="ob-2">
							<span>A freelance web developer</span>
						</h2>
						<a href="#about" rel="m_PageScroll2id" class="sliderBtn wave bg-white c1">Learn more</a>
					</div>
				</div>
			</div>
		</div>
		<div class="ms2-item bg1 f1">
			<div class="row justify-content-center align-items-center h-100">
				<div class="col-lg-8">
					<div class="ms2-content">
						<h1 class="ob-1 cw fw-7">a UI/UX designer</h1>
						<h2 class="ob-2">
							<span>welcome to my virtual world</span>
						</h2>
						<a href="#about" rel="m_PageScroll2id" class="sliderBtn wave bg-white c1">Learn more</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>