<input type="checkbox" class="nav-btn d-none" id="navbtn">
<label for="navbtn">
	<span></span>
	<span></span>
	<span></span>
</label>
<ul>
	<li>
		<a href="#home"></a>
	</li>
	<li>
		<a href="#about"></a>
	</li>
	<li>
		<a href="#resume"></a>
	</li>
	<li>
		<a href="#skill"></a>
	</li>
	<li>
		<a href="#works"></a>
	</li>
	<li>
		<a href="#blog"></a>
	</li>
	<li>
		<a href="#contact"></a>
	</li>
</ul>