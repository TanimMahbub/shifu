<?php 
	$title = 'Master Shifu';
	include_once('inc/head.php');
?>

	<!-- page-wrapper start -->
	<div class="page-wrapper">
	
		<?php
			include_once('inc/mainSlider.php');
			include_once('inc/section-about.php');
		?>

	</div>
	<!-- page-wrapper end -->

	<?php 
		include_once('inc/js.php'); 
	?>